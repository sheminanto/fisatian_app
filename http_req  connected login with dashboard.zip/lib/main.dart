import 'package:flutter/material.dart';
import 'package:http_req/homePage.dart';
import 'sidebar/sidebar_layout.dart';

// void main() => runApp(MyApp());

// class MyApp extends StatelessWidget {
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'Login App',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: HomePage(),
//       initialRoute: '/home',
//       routes: {
//         '/home': (context) => HomePage(),
//         '/home': (context) => SideBarLayout(),
//       },
//     );
//   }
// }

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    initialRoute: '/',
    theme: ThemeData(
      primarySwatch: Colors.blue,
    ),
    routes: <String, WidgetBuilder>{
      '/': (context) => HomePage(),
      '/second': (context) => SideBarLayout(),
    },
  ));
}
