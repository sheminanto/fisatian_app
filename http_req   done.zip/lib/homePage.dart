import 'package:flutter/material.dart';
import 'package:http_req/animations/fadeAnimation.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:flushbar/flushbar.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class Note {
  String subject, total, attended, percentage;

  Note(this.subject, this.total, this.attended, this.percentage);

  // Note.fromJson(Map<String, dynamic> json) {
  //   subject = json['subject'];
  //   total = json['total'];
  //   attended = json['attended'];
  //   percentage = json['percentage'];
  // }
}

class _HomePageState extends State<HomePage> {
  // List<Note> _notes;
  Future<List<Note>> lala;

  Future<List<Note>> fetchNotes(String username, String password) async {
    username = username.trim();
    password = password.trim();

    String url = "http://fisatian1.herokuapp.com/user";
    var headers = {"Accept": "application/json"};
    var body = {'username': username, 'password': password};

    final http.Response response =
        await http.post(url, headers: headers, body: body);

    List<Note> notes = [];
    if (response.statusCode == 200) {
      if (response.body != 'false') {
        var notesJson = json.decode(response.body);
        for (var u in notesJson) {
          Note note =
              Note(u["subject"], u["total"], u["attended"], u["percentage"]);
          notes.add(note);
        }

        print("shemin   -------------------------");
        print(notes.length);
        return notes;
      } else {
        print("INCORRECT USERNAME AND PASSWORD");
        if (notes.isEmpty) {
          print(" notes == []");
        }

        return notes;
      }
    } else {
      print("CONNECTION ERROR !");
      return notes;
    }

    // if (response.statusCode == 200) {
    //
    //   for (var noteJson in notesJson) {
    //     notes.add(Note.fromJson(noteJson));
    //   }
    // }
    // return notes;
  }

  final TextEditingController controller1 = TextEditingController();
  final TextEditingController controller2 = TextEditingController();

  final GlobalKey<ScaffoldState> _scafkey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scafkey,
        body: (lala == null)
            ? mainContainer()
            : FutureBuilder(
                future: lala,
                builder: (context, snapshot) {
                  List<Note> test1;

                  if (snapshot.connectionState == ConnectionState.done) {
                    if (snapshot.hasData) {
                      test1 = snapshot.data;
                      if (test1.isEmpty) {
                        // lala = null;
                        final snackBar = SnackBar(
                            content: Text("Incorrect username and password"));

                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          Scaffold.of(context)
                            ..hideCurrentSnackBar()
                            ..showSnackBar(snackBar);
                        });

                        // WidgetsBinding.instance.addPostFrameCallback((_) {
                        //   Navigator.pushReplacementNamed(context, '/home');
                        // });

                        return mainContainer();
                      } else {
                        print(snapshot.data[0].subject);
                        return Container(
                            alignment: Alignment.center,
                            child: Text(snapshot.data[0].subject));
                      }
                    } else if (snapshot.hasError) {
                      print("shemin ---------- error snapshot");

                      return Text("${snapshot.error}");
                    }
                  } else {
                    return Container(
                        alignment: Alignment.center,
                        child: CircularProgressIndicator());
                  }
                  return Container(
                      alignment: Alignment.center,
                      child: CircularProgressIndicator());
                },
              ));
  }

  mainContainer() {
    return Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, colors: [
          Color(0xFFF206ffd),
          Color(0xFFF3280fb),
          Color(0xFFF28c3eb)
        ])),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(height: 90),
            Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  FadeAnimation(
                      1.2,
                      Text("FISATIAN",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.bold))),
                ],
              ),
            ),
            SizedBox(height: 35),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                    color: Color(0xFFFf4f7fc),
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(35),
                        topLeft: Radius.circular(35))),
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SizedBox(height: 50),
                        FadeAnimation(
                            1.6,
                            Container(
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                        color: Colors.black.withOpacity(0.1),
                                        blurRadius: 8,
                                        offset: Offset(0, 3))
                                  ]),
                              child: Container(
                                padding: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom:
                                            BorderSide(color: Colors.grey))),
                                child: TextField(
                                  controller: controller1,
                                  decoration: InputDecoration(
                                      hintText: "Username",
                                      hintStyle: TextStyle(color: Colors.grey),
                                      border: InputBorder.none),
                                ),
                              ),
                            )),
                        SizedBox(height: 10),
                        FadeAnimation(
                            1.9,
                            Container(
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                        color: Colors.black.withOpacity(0.1),
                                        blurRadius: 8,
                                        offset: Offset(0, 3))
                                  ]),
                              child: Container(
                                padding: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom:
                                            BorderSide(color: Colors.grey))),
                                child: TextField(
                                  controller: controller2,
                                  obscureText: true,
                                  decoration: InputDecoration(
                                      hintText: "Password",
                                      hintStyle: TextStyle(color: Colors.grey),
                                      border: InputBorder.none),
                                ),
                              ),
                            )),
                        SizedBox(height: 30),
                        FadeAnimation(
                            2,
                            Text("Forget your password?",
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Color(0xFFF3a6eff),
                                    fontWeight: FontWeight.bold))),
                        SizedBox(height: 40),
                        FadeAnimation(
                            2.2,
                            GestureDetector(
                                onTap: () {
                                  setState(() {
                                    String _uname = controller1.text;
                                    String _upass = controller2.text;
                                    controller1.clear();
                                    controller2.clear();

                                    lala = fetchNotes(_uname, _upass);
                                  });
                                },
                                child: Container(
                                  height: 60,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(50),
                                      gradient: LinearGradient(
                                          begin: Alignment.centerRight,
                                          colors: [
                                            Color(0xFFF206ffd),
                                            Color(0xFFF3280fb)
                                          ])),
                                  child: Center(
                                    child: Text("Login",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold)),
                                  ),
                                )))
                      ],
                    ),
                  ),
                ),
              ),
            )
          ],
        ));
  }
}
