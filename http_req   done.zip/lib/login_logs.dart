class Loginlogs {
  bool logs;

  Loginlogs(this.logs);
}
